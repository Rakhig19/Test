<?php
/*
* Plugin Name:My Plugin
*Description: WordPress Backend Paradiso API
*Version:6.2
*Author:Rakhi Gupta 
*Plugin URI:http://localhost/Bootstrap/
*
*
*/

// Don't access this file directly.
defined('ABSPATH') or die();
if(!defined('ABSPATH')){

    header("Location://http://localhost/bootstrap/");
    die();

   
}

function my_plugin_activation(){
    global $wpdb, $table_prefix;
    $wp_emp = $table_prefix.'emp';

    $my_query = "CREATE TABLE IF NOT EXISTS .`$wp_emp` ( `Id` INT NULL AUTO_INCREMENT , `name` VARCHAR(250) NOT NULL , `email` VARCHAR(250) NOT NULL , `status` BOOLEAN NOT NULL , PRIMARY KEY (`Id`)) ENGINE = InnoDB;";
    $wpdb->query($my_query);

    //$insert_query ="INSERT INTO `$wp_emp` (`name`, `email`, `status`) VALUES ('Test', 'test123@test.com', 1)";
    
    $data = array(
        'name' => 'Test',
        'email' => 'Test1234@test.com',
        'status' => 1
    );
    $wpdb->insert($wp_emp,$data);

}
register_activation_hook(__FILE__,'my_plugin_activation');


function my_plugin_deactivation(){

    global $wpdb, $table_prefix;
    $wp_emp = $table_prefix.'emp';
    $q = "TRUNCATE.`$wp_emp`";
    $wpdb->query($q);

}
register_deactivation_hook(__FILE__,'my_plugin_deactivation');


function function_my_shortcode(){
    echo "short code";
}
add_shortcode('my-sc','function_my_shortcode');

define("PLUGIN_DIR_PATH",plugin_dir_path(__FILE__));
define("PLUGIN_URL",plugins_url());
define("PLUGIN_VERSION","1.0");

/* function add_my_custom_menu(){

   

    add_menu_page(
        "pardisco_api",        // page title
        "Paradisco API",        // Menu Title
        "manage_options",       // admin level
        "pardisco_api1",        // page slug
        "custom_admin_view",   // call back function
        "dashicons-rest-api",    // icon url
        11
    );
    add_submenu_page(
        "pardisco_api1",   //parent slug
        "Add New",             // page title 
        "Add New",              // menu title
        "manage_options",  
        "pardisco_api1",
        "add_new_function"
    );
    add_submenu_page(
        "pardisco_api1",   //parent slug
        "All Pages",             // page title 
        "All Pages",              // menu title
        "manage_options",  
        "All-page",
        "all_page_function"
    );
   
}
add_action("admin_menu","add_my_custom_menu");

function custom_admin_view(){
   // echo  "hi and welcome";
}


function add_new_function(){
   include_once  PLUGIN_DIR_PATH."/views/add-new.php";
   add_shortcode('rest-apis','paradisco_rest_apis_shortcode');
}


function all_page_function(){
    include_once  PLUGIN_DIR_PATH."/views/all-page.php";
   
}

// api code start here 
add_shortcode('rest-ajax','paradisco_rest_ajax_shortcode');

function paradisco_rest_ajax_shortcode(){
    ?>
  <p id="paradisco-text">shortcode here 12345</p>
<?php 
  //Write ajax to show  the information in shortcode
    wp_enqueue_script('rest-ajax-script',plugins_url('assets/js/script.js',__FILE__),['jquery'],'0.1.0',true);
}

add_action('rest_api_init','paradisco_rest_api_endpoint');
function paradisco_rest_api_endpoint(){
    register_rest_route(
        'paradisco',
        'rest_ajax',
        [
            'methods' => 'GET',
            'permission_callback' => '_return_true',
            'callback' => 'paradisco_rest_ajax_callback'
        ]


    );

}

function paradisco_rest_ajax_callback(){

    $data = '';
    $args = [
        'methods' => 'GET',

    ];
  //  $response = wp_remote_get('https://jsonplaceholder.typicode.com/posts',$args);
    $response = wp_remote_get('https://jsonplaceholder.typicode.com/posts',$args);

    $response = wp_remote_retrieve_body($response);

    $response = json_decode($response);
    return $response;

}

// // api code end  here 

//add css and js file function

function custom_plugin_assets(){
    wp_enqueue_style(
        "cpl_style",    // unique name for css file
        PLUGIN_URL."/paradisoAPI/assets/css/style.css" ,     // Add css file
        ' ',     //dependency  of file
        PLUGIN_VERSION    // plugin version
        
);

wp_enqueue_script(
    "cpl_script",    // unique name for css file
    PLUGIN_URL."/paradisoAPI/assets/js/script1.js" ,     // Add css file
    ' ',     //dependency  of file
    PLUGIN_VERSION,    // plugin version
    true
    
);

wp_localize_script("cpl_script","ajaxurl",admin_url("admin-ajax.php"));

}
add_action("init","custom_plugin_assets");

if(isset($_REQUEST['action'])){     //check the action param is set or not

    switch($_REQUEST['action']){        // is set pass to switch method to match case
        case "custom_plugin_library" : 
            add_action("admin_init","add_custom_plugin_library");        // match case
            function  add_custom_plugin_library(){      // function attached with the action hook
                global $wpdb;
                include_once  PLUGIN_DIR_PATH."/library/custom_plugin_lib.php";      // ajax handle file within/library folder
            }
            break;
    }
}

function myjscode(){
    ?>
    <script type="text/javascript">
       
    </script>
    <?php
}
add_action("wp_head","myjscode");
?>

<?php 

add_shortcode('external_date','callback_function_api') */
?>