<?php
/* Silence is good */
?>